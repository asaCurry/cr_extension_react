import React from 'react';
import PropTypes from 'prop-types';

const GuestList = props =>

<ul>
  <li> a thing! </li>
</ul>;

export default GuestList;
